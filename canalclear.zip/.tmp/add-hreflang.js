const fs = require('fs');

// Map of file path -> canonical URL
const pages = [
  { file: 'public/index.html', url: 'https://canalclear.org/' },
  { file: 'public/pricing.html', url: 'https://canalclear.org/pricing' },
  { file: 'public/about.html', url: 'https://canalclear.org/about' },
  { file: 'public/knowledge-base.html', url: 'https://canalclear.org/knowledge-base' },
  { file: 'public/podcast.html', url: 'https://canalclear.org/podcast' },
  { file: 'public/blog/index.html', url: 'https://canalclear.org/blog' },
  { file: 'public/blog/how-to-avoid-panama-canal-compliance-fines-in-2026.html', url: 'https://canalclear.org/blog/how-to-avoid-panama-canal-compliance-fines-in-2026' },
  { file: 'public/blog/how-to-file-pcsopep-panama-canal.html', url: 'https://canalclear.org/blog/how-to-file-pcsopep-panama-canal' },
  { file: 'public/blog/how-to-file-vumpa-panama-canal.html', url: 'https://canalclear.org/blog/how-to-file-vumpa-panama-canal' },
  { file: 'public/blog/how-to-reduce-shipping-delays.html', url: 'https://canalclear.org/blog/how-to-reduce-shipping-delays' },
  { file: 'public/blog/marpol-compliance-checklist-ship-operators-2026.html', url: 'https://canalclear.org/blog/marpol-compliance-checklist-ship-operators-2026' },
  { file: 'public/blog/panama-canal-compliance-checklist-2026.html', url: 'https://canalclear.org/blog/panama-canal-compliance-checklist-2026' },
  { file: 'public/blog/panama-canal-compliance-checklist-fleet-operators.html', url: 'https://canalclear.org/blog/panama-canal-compliance-checklist-fleet-operators' },
  { file: 'public/blog/panama-canal-transit-documents-required.html', url: 'https://canalclear.org/blog/panama-canal-transit-documents-required' },
  { file: 'public/blog/panama-canal-vumpa-requirements-2026.html', url: 'https://canalclear.org/blog/panama-canal-vumpa-requirements-2026' },
  { file: 'public/blog/pcsopep-requirements-panama-canal.html', url: 'https://canalclear.org/blog/pcsopep-requirements-panama-canal' },
  { file: 'public/blog/true-cost-of-non-compliance-global-shipping.html', url: 'https://canalclear.org/blog/true-cost-of-non-compliance-global-shipping' },
  { file: 'public/blog/what-is-port-state-control.html', url: 'https://canalclear.org/blog/what-is-port-state-control' },
  { file: 'public/blog/why-ai-is-the-future-of-panama-canal-compliance.html', url: 'https://canalclear.org/blog/why-ai-is-the-future-of-panama-canal-compliance' },
];

// Languages to support
const langs = ['en', 'es', 'zh', 'el', 'ja'];

let updated = 0;
let skipped = 0;

for (const { file, url } of pages) {
  const content = fs.readFileSync(file, 'utf8');

  // Skip if hreflang already present
  if (content.includes('rel="alternate" hreflang=')) {
    console.log(`SKIP (already has hreflang): ${file}`);
    skipped++;
    continue;
  }

  // Build hreflang block
  const hreflangTags = langs.map(lang =>
    `    <link rel="alternate" hreflang="${lang}" href="${url}">`
  ).join('\n') + '\n' +
    `    <link rel="alternate" hreflang="x-default" href="${url}">`;

  // Find canonical tag and insert hreflang after it
  const canonicalRegex = /(<link rel="canonical"[^>]*>)/;
  if (canonicalRegex.test(content)) {
    const newContent = content.replace(canonicalRegex, `$1\n${hreflangTags}`);
    fs.writeFileSync(file, newContent, 'utf8');
    console.log(`UPDATED: ${file}`);
    updated++;
  } else {
    console.log(`NO CANONICAL FOUND: ${file}`);
  }
}

console.log(`\nDone: ${updated} updated, ${skipped} skipped`);
