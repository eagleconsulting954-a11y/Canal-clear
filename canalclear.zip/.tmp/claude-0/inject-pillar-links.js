const fs = require('fs');
const path = require('path');

const BLOG_DIR = path.join(__dirname, '../../public/blog');

// Skip blog index
const POSTS = fs.readdirSync(BLOG_DIR)
  .filter(f => f.endsWith('.html') && f !== 'index.html');

const PILLAR_BLOCK = `
    <div class="article-divider"></div>
    <div class="callout" style="margin-top:2rem">
        <p>📋 <strong>This article is part of the <a href="/compliance-guide" style="color:var(--teal);text-decoration:none;border-bottom:1px solid rgba(0,212,170,0.3)">Panama Canal Compliance Guide</a></strong> — the definitive hub covering VUMPA, PCSOPEP, crew manifests, cargo declarations, ballast water, mooring, and all ACP transit requirements in one place.</p>
    </div>
`;

let updated = 0;
let skipped = 0;

POSTS.forEach(filename => {
  const filePath = path.join(BLOG_DIR, filename);
  let content = fs.readFileSync(filePath, 'utf8');

  // Skip if already has the pillar link
  if (content.includes('/compliance-guide')) {
    console.log(`  SKIP (already linked): ${filename}`);
    skipped++;
    return;
  }

  // Inject just before </article>
  if (content.includes('</article>')) {
    content = content.replace('</article>', PILLAR_BLOCK + '\n    </article>');
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`  OK Updated: ${filename}`);
    updated++;
  } else {
    console.log(`  WARN No </article> found: ${filename}`);
  }
});

console.log(`\nDone. Updated: ${updated}, Skipped: ${skipped}`);
