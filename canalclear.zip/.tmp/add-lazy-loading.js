const fs = require('fs');
const { execSync } = require('child_process');

// Get all public HTML files
const files = execSync('find public -name "*.html"')
  .toString().trim().split('\n').filter(Boolean);

let totalUpdated = 0;

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  const original = content;

  // Strategy: add loading="lazy" to any img tag inside a <footer> element
  // Use a state-machine approach to find footer boundaries
  const footerStart = content.indexOf('<footer');
  const footerEnd = content.lastIndexOf('</footer>');

  if (footerStart === -1 || footerEnd === -1) continue;

  const before = content.slice(0, footerStart);
  let footerSection = content.slice(footerStart, footerEnd + 9); // +9 for </footer>
  const after = content.slice(footerEnd + 9);

  // Add loading="lazy" to img tags in footer that don't already have loading=
  const updatedFooter = footerSection.replace(
    /<img(?![^>]*\bloading=)([^>]*>)/g,
    '<img loading="lazy"$1'
  );

  if (updatedFooter !== footerSection) {
    content = before + updatedFooter + after;
    fs.writeFileSync(file, content, 'utf8');
    totalUpdated++;
    console.log(`UPDATED footer imgs: ${file}`);
  }
}

console.log(`\nDone: ${totalUpdated} files updated`);
