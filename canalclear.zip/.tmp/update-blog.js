const fs = require('fs');
const path = require('path');

const blogDir = '/opt/polsia/workspaces/company-47541/agent-30/exec-1549018/canalclear/public/blog';

const oldText = '<p>\u{1F4CB} <strong>This article is part of the <a href="/compliance-guide" style="color:var(--teal);text-decoration:none;border-bottom:1px solid rgba(0,212,170,0.3)">Panama Canal Compliance Guide</a></strong> \u2014 the definitive hub covering VUMPA, PCSOPEP, crew manifests, cargo declarations, ballast water, mooring, and all ACP transit requirements in one place.</p>';

const newText = '<p>\u{1F4CB} <strong>This article is part of the <a href="/compliance-guide" style="color:var(--teal);text-decoration:none;border-bottom:1px solid rgba(0,212,170,0.3)">Panama Canal Compliance Guide</a></strong> \u2014 the definitive hub covering VUMPA, PCSOPEP, crew manifests, cargo declarations, ballast water, mooring, and all ACP transit requirements in one place. \u2192 <a href="/guide" style="color:var(--teal);text-decoration:none;font-weight:700;border-bottom:1px solid rgba(0,212,170,0.3)">Read the Complete Guide 2026</a></p>';

const files = fs.readdirSync(blogDir).filter(function(f) {
  return f.endsWith('.html') && f \!== 'index.html';
});

let updated = 0;

for (let i = 0; i < files.length; i++) {
  const file = files[i];
  const filepath = path.join(blogDir, file);
  const content = fs.readFileSync(filepath, 'utf8');
  if (content.includes(oldText)) {
    const newContent = content.replace(oldText, newText);
    fs.writeFileSync(filepath, newContent, 'utf8');
    updated++;
    console.log('Updated: ' + file);
  }
}

console.log('Total updated: ' + updated);
