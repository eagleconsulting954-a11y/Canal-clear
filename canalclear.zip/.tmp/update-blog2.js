const fs = require('fs');
const path = require('path');

const blogDir = '/opt/polsia/workspaces/company-47541/agent-30/exec-1549018/canalclear/public/blog';

const files = fs.readdirSync(blogDir).filter(function(f) {
  const notIndex = f.indexOf('index.html') === -1;
  return f.endsWith('.html') && notIndex;
});

let updated = 0;

for (let i = 0; i < files.length; i++) {
  const file = files[i];
  const filepath = path.join(blogDir, file);
  let content = fs.readFileSync(filepath, 'utf8');
  const idx = content.indexOf('in one place.</p>');
  if (idx \!== -1) {
    const replacement = 'in one place. \u2192 <a href="/guide" style="color:var(--teal);text-decoration:none;font-weight:700;border-bottom:1px solid rgba(0,212,170,0.3)">Read the Complete Guide 2026</a></p>';
    content = content.slice(0, idx) + replacement + content.slice(idx + 'in one place.</p>'.length);
    fs.writeFileSync(filepath, content, 'utf8');
    updated++;
    console.log('Updated: ' + file);
  }
}

console.log('Total updated: ' + updated);
