const fs = require("fs");
const path = require("path");

const blogDir = "/opt/polsia/workspaces/company-47541/agent-30/exec-1549018/canalclear/public/blog";

const files = fs.readdirSync(blogDir).filter(function(f) {
  return f.endsWith(".html") && f.indexOf("index.html") === -1;
});

let updated = 0;

for (let i = 0; i < files.length; i++) {
  const file = files[i];
  const filepath = path.join(blogDir, file);
  let content = fs.readFileSync(filepath, "utf8");
  const MARKER = "in one place.</p>";
  const REPLACEMENT = "in one place. \u2192 <a href=\"/guide\" style=\"color:var(--teal);text-decoration:none;font-weight:700;border-bottom:1px solid rgba(0,212,170,0.3)\">Read the Complete Guide 2026</a></p>";
  const idx = content.indexOf(MARKER);
  if (idx > -1) {
    content = content.slice(0, idx) + REPLACEMENT + content.slice(idx + MARKER.length);
    fs.writeFileSync(filepath, content, "utf8");
    updated++;
    console.log("Updated: " + file);
  }
}

console.log("Total updated: " + updated);
